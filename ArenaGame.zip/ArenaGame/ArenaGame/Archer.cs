﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArenaGame
{
    public class Archer : Hero
    {
        public int Arrows { get; private set; }

        public Archer(string name) : base(name)
        {
            Strength = 10;
            Arrows = 30;
        }
    }
}

