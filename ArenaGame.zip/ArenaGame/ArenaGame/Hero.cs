﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ArenaGame
{
    public abstract class Hero
    {
        public string Name { get; private set; }
        public int Health { get; private set; }
        public int Strength { get; protected set; }
        protected int StartingHealth { get; private set; }
        public bool IsDead { get { return Health <= 0; } }

        private readonly Random random = new Random();

        public Hero(string name)
        {
            Name = name;
            Health = 500;
            StartingHealth = Health;
            Strength = 100;
        }

        public virtual int Attack()
        {
            return (Strength * random.Next(80, 121)) / 100;
        }

        public virtual void TakeDamage(int incomingDamage)
        {
            if (ThrowDice(30)) incomingDamage = 0;
            Health -= incomingDamage;
        }

        protected bool ThrowDice(int chance)
        {
            int dice = random.Next(101);
            return dice <= chance;
        }

        public void Heal(int value)
        {
            Health += value;
            if (Health > StartingHealth) Health = StartingHealth;
        }


    }
}
