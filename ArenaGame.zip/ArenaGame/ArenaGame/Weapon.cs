﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArenaGame
{
    public class Weapon
    {
        public string Name { get; }
        public int AttackBoost { get; }
        public Action<Hero, Hero> SpecialAbility { get; }

        public Weapon(string name, int attackBoost, Action<Hero, Hero> specialAbility = null)
        {
            Name = name;
            AttackBoost = attackBoost;
            SpecialAbility = specialAbility;
        }

        public void ApplySpecialAbility(Hero attacker, Hero defender)
        {
            SpecialAbility?.Invoke(attacker, defender);
        }
    }
}


