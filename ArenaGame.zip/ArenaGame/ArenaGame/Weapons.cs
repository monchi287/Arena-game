﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArenaGame
{
    public static class Weapons
    {
        public static Weapon FlamingSword { get; } = new Weapon(
            "Flaming Sword",
            10,
            (attacker, defender) => defender.TakeDamage(5)
        );

        public static Weapon PoisonArrow { get; } = new Weapon(
            "Poison Arrow",
            7,
            (attacker, defender) => defender.TakeDamage(2)
        );

        public static Weapon HealingStaff { get; } = new Weapon(
            "Healing Staff",
            5,
            (attacker, defender) => attacker.Heal(3)
        );
    }
}

